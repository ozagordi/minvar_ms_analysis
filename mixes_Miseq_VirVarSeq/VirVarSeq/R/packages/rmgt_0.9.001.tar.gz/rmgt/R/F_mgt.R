#' Estimating a truncated mixture of normal distributions
#'
#' This function uses the algorithm of Jones and McLachan to estimate the means and variances of a mixture of normal distributions on grouped and truncated data. It is mainly a wrapper function around the original Fortran code.
#'
#' You can use the parameter \code{nx} to provide the frequencies of the different classes, and give the break points as a numeric vector using \code{breaks}. This vector needs to be one longer than the vector \code{nx} in the case of truncated data. In case the data is not truncated, you can use \code{-Inf} and \code{Inf} as lowest and highest breakpoint, or you can give a vector with breakpoints that's one value shorter than \code{nx}. The function will automatically add the outer breakpoints.
#'
#' Although it's theoretically possible to use this function on untruncated and grouped data, multiple tests have shown that this functionality isn't really strong. It often leads to zero expectations for class frequencies at some point. It's best to leave truncated to TRUE.
#'
#' @param nx the frequencies in case x is not specified. In this case, breaks should be specified.
#' @param truncated boolean value indicating whether the mixture is truncated. Defaults to \code{TRUE}.
#' @param ng number of components in the mixture
#' @param breaks A sorted(!) numerical vector containing the break points used for making the classes. If \code{truncated} is \code{TRUE}, the lowest and highest value are used as the truncation points.
#' @param p.est The estimates for the proportions pi of each distribution in the mixture. If not specified, 
#' @param avg.est The estimates for the averages for each distribution in the mixture
#' @param var.est The estimates for the variances for each distribution in the mixture
#' @param tol The minimal difference between two LL values needed to continue the iterations
#' @param iter The maximal number of iterations
#'
#' @return The function returns a list with the following elements :
#' \describe{
#'      \item{vals}{The estimated values.}
#'      \item{iter}{The number of iterations.}
#'      \item{ll}{The returned log likelihood.}
#'      \item{se}{The standard errors for the estimated values.}
#'}
#' The elements vals and se are lists themselves, containing the following vectors with values for the components in the mixture :
#' \describe{
#'      \item{xbar}{either the estimate or the standard error for the mean.}
#'      \item{var}{either the estimate or the standard error for the variance.}
#'      \item{pr}{either the estimate or the standard error for the proportions.}
#'}
#'
#' @note This is a simple wrapper around the Fortran algorithm! It returns the error messages in case there's a problem, but be aware that the performance of this algorithm is pretty dependent on the starting values/estimates you pass to the fortran code.
#'
#' @references 
#' McLachlan, G.J., Jones, P.N. (1988) Fitting Mixture Models to Grouped and Truncated Data via the EM Algorithm Biometrics, 44, 571-578.
#' 
#' @useDynLib rmgt
#' @export
#' @author Joris Meys
mgt <- function(
       nx,
       truncated=TRUE,
       ng = 2,
       breaks=NULL,
       p.est,
       avg.est,
       var.est,
       tol = 1.0e-8,
       iter = 1000L,
       ...       
){
       
   itrunc <- as.integer(truncated)

   if(missing(nx))
        stop("Please specify the frequencies")              

   nr <- length(nx)
   if(is.null(breaks)) 
         stop('Specify breaks if you specified nx')
   if(is.unsorted(breaks)) 
         stop('Breaks should be sorted')
  
   if(!truncated){
   
      if(is.infinite(min(breaks)) & is.infinite(max(breaks)))
          breaks <- breaks[-c(1,length(breaks))]
      nb <- length(breaks)
      if(nr - 1 != nb)
          stop("Length of breaks not compatible with length nx")
      nl <- nx[1]
      nu <- nx[nr]
      nx <- nx[-c(1,nr)]

   } else {
   
      if(length(breaks)!=nr+1)
          stop('Length of breaks should be one more than nx')
      nl <- integer(1)
      nu <- integer(1)   
   }               

   lowend <- breaks[1]
   upends <- breaks[-1]          

   
   if(missing(p.est)) p.est <- rep(1/ng,ng)
   
   kw = 4 * ng * ( nr + 2 + 3 * ng ) + ( nr + 2 ) # see paper
    
   out <- .Fortran('mgt',
            NG = as.integer(ng),           # Number of mixture components
            NR = as.integer(nr),           # Number of classes
            ITRUNC = as.integer(itrunc),   # Truncation or not (1 is truncated)
            X0 = as.single(lowend),       # lower end point of first class
            X = as.single(upends),        # upper end point of classes
            NL = as.integer(nl),           # frequency lower class if not truncated
            NU = as.integer(nu),           # frequency upper class if not truncated
            N = as.integer(nx),             # frecuencies of each class
            WK = single(kw),
            KW = as.integer(kw),           # dimensions of the workspace
            PI = as.single(p.est),        # initial estimate of pi
            XBAR = as.single(avg.est),    # initial estimate of the averages
            VAR = as.single(var.est),     # initial estimate of the variances
            PSE = single(ng),
            XSE = single(ng),
            VSE = single(ng),
            TOL = as.single(tol),         # tolerance : relative diff of 2 LL values to terminate calculations
            XLOGL = single(1),
            ITER = as.integer(iter),       # maximum number of iterations 
            IFAULT = 0L,
            PACKAGE='rmgt'
            )
   
   vals <- list(xbar=numeric(0),var=numeric(0),pr=numeric(0))
   se  <- list(xbar=numeric(0),var=numeric(0),pr=numeric(0))
   for(i in seq_len(ng)){
        vals$xbar[i] <- out$XBAR[i]
        vals$var[i] <- out$VAR[i]
        vals$pr[i] <- out$PI[i]

        se$xbar[i] <- out$XSE[i]
        se$var[i] <- out$VSE[i]
        se$pr[i] <- out$PSE[i]

   }
   
   if(out$IFAULT != 0){
      msg <- switch(out$IFAULT,
        "The number of components in the mixture exceeds the number of classes",
        "The values for p.est should be between 0 and 1.",
        "The values for p.est should sum to 1.",
        "The values for var.est should be larger than 0.",
        "Maximum number of iterations reached.",
        "Starting values give zero expectations for class frequencies."
      )
      if(out$IFAULT != 5) stop(msg) else warning(msg)
   }
   
   return(list(vals=vals,se=se,iter=out$ITER,ll = out$XLOGL))
}